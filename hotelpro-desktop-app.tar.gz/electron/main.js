const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

// Keep a global reference of the window object
let mainWindow;
let serverProcess;

function createWindow() {
  // Create the browser window
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    icon: path.join(__dirname, 'assets', 'icon.png'), // You can add an icon later
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      webSecurity: true
    },
    titleBarStyle: 'default',
    show: false // Don't show until ready
  });

  // Arabic RTL support
  mainWindow.setTitle('نظام إدارة الفندق - HotelPro');

  // Start the Express server
  startServer();

  // Load the app
  mainWindow.loadURL('http://localhost:5000');

  // Show window when ready to prevent visual flash
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Handle window closed
  mainWindow.on('closed', () => {
    mainWindow = null;
    // Kill server process
    if (serverProcess) {
      serverProcess.kill();
    }
  });

  // Open DevTools in development
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }
}

function startServer() {
  // Start the Express server
  const isDev = process.env.NODE_ENV === 'development';
  const serverPath = isDev 
    ? path.join(__dirname, '..', 'server', 'index.ts')
    : path.join(__dirname, '..', 'dist', 'index.js');
  
  const command = isDev ? 'tsx' : 'node';
  
  serverProcess = spawn(command, [serverPath], {
    env: { ...process.env, NODE_ENV: isDev ? 'development' : 'production' },
    stdio: 'inherit'
  });

  serverProcess.on('error', (err) => {
    console.error('Server process error:', err);
  });
}

// Create menu for Arabic RTL support
function createMenu() {
  const template = [
    {
      label: 'ملف',
      submenu: [
        {
          label: 'إغلاق',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'عرض',
      submenu: [
        {
          label: 'إعادة تحميل',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            mainWindow.reload();
          }
        },
        {
          label: 'تبديل أدوات المطور',
          accelerator: 'F12',
          click: () => {
            mainWindow.webContents.toggleDevTools();
          }
        }
      ]
    },
    {
      label: 'نافذة',
      submenu: [
        {
          label: 'تصغير',
          accelerator: 'CmdOrCtrl+M',
          role: 'minimize'
        },
        {
          label: 'إغلاق',
          accelerator: 'CmdOrCtrl+W',
          role: 'close'
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// App event listeners
app.whenReady().then(() => {
  createWindow();
  createMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  // Kill server process
  if (serverProcess) {
    serverProcess.kill();
  }
  
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  // Kill server process
  if (serverProcess) {
    serverProcess.kill();
  }
});
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Invoice, Reservation, Guest, Room, InsertInvoice, insertInvoiceSchema } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Plus, Search, FileText, Printer, DollarSign, Clock, CheckCircle, XCircle } from "lucide-react";

export default function Billing() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const { data: reservations = [] } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
  });

  const { data: guests = [] } = useQuery<Guest[]>({
    queryKey: ["/api/guests"],
  });

  const { data: rooms = [] } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const form = useForm<InsertInvoice>({
    resolver: zodResolver(insertInvoiceSchema),
    defaultValues: {
      reservationId: "",
      amount: "0",
      status: "pending",
    },
  });

  const createInvoiceMutation = useMutation({
    mutationFn: async (data: InsertInvoice) => {
      return apiRequest("POST", "/api/invoices", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Success",
        description: "Invoice created successfully",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create invoice",
        variant: "destructive",
      });
    },
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertInvoice> }) => {
      return apiRequest("PATCH", `/api/invoices/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Success",
        description: "Invoice updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update invoice",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertInvoice) => {
    createInvoiceMutation.mutate(data);
  };

  const updateInvoiceStatus = (id: string, status: string) => {
    const updates: any = { status };
    if (status === "paid") {
      // Set paid timestamp when marking as paid
      updates.paidAt = new Date();
    }
    updateInvoiceMutation.mutate({ id, data: updates });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-warning text-white";
      case "paid":
        return "bg-success text-white";
      case "cancelled":
        return "bg-error text-white";
      default:
        return "bg-neutral-400 text-white";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "paid":
        return <CheckCircle className="w-4 h-4" />;
      case "cancelled":
        return <XCircle className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getReservationDetails = (reservationId: string) => {
    const reservation = reservations.find(r => r.id === reservationId);
    if (!reservation) return { guestName: "Unknown", roomNumber: "Unknown" };

    const guest = guests.find(g => g.id === reservation.guestId);
    const room = rooms.find(r => r.id === reservation.roomId);

    return {
      guestName: guest ? `${guest.firstName} ${guest.lastName}` : "Unknown Guest",
      roomNumber: room ? room.number : "Unknown Room",
    };
  };

  const filteredInvoices = invoices.filter((invoice) => {
    const { guestName, roomNumber } = getReservationDetails(invoice.reservationId);
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = guestName.toLowerCase().includes(searchLower) ||
                         roomNumber.toLowerCase().includes(searchLower) ||
                         invoice.amount.includes(searchTerm);
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Get reservations that don't have invoices yet
  const reservationsWithoutInvoices = reservations.filter(r => 
    r.status === "checked_out" && !invoices.some(i => i.reservationId === r.id)
  );

  const printInvoice = (invoice: Invoice) => {
    const { guestName, roomNumber } = getReservationDetails(invoice.reservationId);
    const reservation = reservations.find(r => r.id === invoice.reservationId);
    
    if (!reservation) {
      toast({
        title: "Error",
        description: "Reservation not found for this invoice",
        variant: "destructive",
      });
      return;
    }

    // Create a simple print window
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const checkInDate = new Date(reservation.checkInDate).toLocaleDateString();
    const checkOutDate = new Date(reservation.checkOutDate).toLocaleDateString();
    const invoiceDate = new Date(invoice.createdAt!).toLocaleDateString();

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${invoice.id}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            .header { text-align: center; margin-bottom: 30px; }
            .invoice-details { margin-bottom: 30px; }
            .line-item { display: flex; justify-content: space-between; margin: 10px 0; }
            .total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; }
            @media print { button { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>HotelPro Invoice</h1>
            <p>Invoice #: ${invoice.id}</p>
            <p>Date: ${invoiceDate}</p>
          </div>
          
          <div class="invoice-details">
            <h3>Guest Information</h3>
            <p><strong>Name:</strong> ${guestName}</p>
            <p><strong>Room:</strong> ${roomNumber}</p>
            <p><strong>Check-in:</strong> ${checkInDate}</p>
            <p><strong>Check-out:</strong> ${checkOutDate}</p>
          </div>
          
          <div class="line-items">
            <h3>Charges</h3>
            <div class="line-item">
              <span>Room Charges</span>
              <span>$${reservation.totalAmount}</span>
            </div>
            <div class="line-item total">
              <span>Total Amount</span>
              <span>$${invoice.amount}</span>
            </div>
          </div>
          
          <div style="margin-top: 40px; text-align: center;">
            <p>Status: ${invoice.status.toUpperCase()}</p>
            ${invoice.status === 'paid' && invoice.paidAt ? `<p>Paid on: ${new Date(invoice.paidAt).toLocaleDateString()}</p>` : ''}
          </div>
          
          <button onclick="window.print()" style="margin-top: 20px;">Print Invoice</button>
        </body>
      </html>
    `);
    
    printWindow.document.close();
  };

  const stats = {
    totalInvoices: invoices.length,
    pendingAmount: invoices.filter(i => i.status === 'pending').reduce((sum, i) => sum + parseFloat(i.amount), 0),
    paidAmount: invoices.filter(i => i.status === 'paid').reduce((sum, i) => sum + parseFloat(i.amount), 0),
    pendingCount: invoices.filter(i => i.status === 'pending').length,
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-neutral-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-neutral-200 rounded-xl"></div>
            ))}
          </div>
          <div className="h-64 bg-neutral-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-neutral-900">الفواتير والمحاسبة</h1>
            <p className="text-neutral-600 mt-1">إدارة الفواتير ومعلومات الفوترة</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-white hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                إنشاء فاتورة
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Generate New Invoice</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="reservationId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reservation</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select reservation" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {reservationsWithoutInvoices.map((reservation) => {
                              const { guestName, roomNumber } = getReservationDetails(reservation.id);
                              return (
                                <SelectItem key={reservation.id} value={reservation.id}>
                                  {guestName} - Room {roomNumber} (${reservation.totalAmount})
                                </SelectItem>
                              );
                            })}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="0.00" 
                            {...field}
                            onChange={(e) => {
                              field.onChange(e.target.value);
                              // Auto-fill amount based on selected reservation
                              const selectedReservation = reservationsWithoutInvoices.find(r => r.id === form.getValues('reservationId'));
                              if (selectedReservation && !e.target.value) {
                                field.onChange(selectedReservation.totalAmount);
                              }
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createInvoiceMutation.isPending}
                    >
                      {createInvoiceMutation.isPending ? "Generating..." : "Generate Invoice"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Total Invoices</p>
                <p className="text-3xl font-bold text-neutral-900 mt-2">{stats.totalInvoices}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="text-blue-600 text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Pending Amount</p>
                <p className="text-3xl font-bold text-warning mt-2">${stats.pendingAmount.toFixed(2)}</p>
                <p className="text-sm text-neutral-500 mt-1">{stats.pendingCount} invoices</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Clock className="text-orange-600 text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Paid Amount</p>
                <p className="text-3xl font-bold text-success mt-2">${stats.paidAmount.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-green-600 text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Collection Rate</p>
                <p className="text-3xl font-bold text-primary mt-2">
                  {stats.totalInvoices > 0 ? ((stats.paidAmount / (stats.paidAmount + stats.pendingAmount)) * 100).toFixed(1) : '0.0'}%
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-blue-600 text-xl" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Invoices ({filteredInvoices.length})</CardTitle>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
                <Input
                  placeholder="Search invoices..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice ID</TableHead>
                <TableHead>Guest</TableHead>
                <TableHead>Room</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((invoice) => {
                const { guestName, roomNumber } = getReservationDetails(invoice.reservationId);
                return (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium font-mono text-sm">
                      {invoice.id.slice(-8)}
                    </TableCell>
                    <TableCell>{guestName}</TableCell>
                    <TableCell>Room {roomNumber}</TableCell>
                    <TableCell className="font-semibold">${invoice.amount}</TableCell>
                    <TableCell>
                      <Select
                        value={invoice.status}
                        onValueChange={(value) => updateInvoiceStatus(invoice.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <Badge className={getStatusColor(invoice.status)}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(invoice.status)}
                              <span>{invoice.status}</span>
                            </div>
                          </Badge>
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="paid">Paid</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      {invoice.createdAt ? new Date(invoice.createdAt).toLocaleDateString() : "Unknown"}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => printInvoice(invoice)}
                        >
                          <Printer className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          
          {filteredInvoices.length === 0 && (
            <div className="text-center py-8 text-neutral-500">
              No invoices found matching your criteria
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

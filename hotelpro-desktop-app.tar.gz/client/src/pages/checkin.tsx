import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Reservation, Guest, Room } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Search, LogIn, LogOut, Clock, Calendar } from "lucide-react";

export default function CheckIn() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reservations = [], isLoading } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
  });

  const { data: guests = [] } = useQuery<Guest[]>({
    queryKey: ["/api/guests"],
  });

  const { data: rooms = [] } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const checkInMutation = useMutation({
    mutationFn: async (reservationId: string) => {
      // Update reservation status and room status
      await apiRequest("PATCH", `/api/reservations/${reservationId}`, { status: "checked_in" });
      const reservation = reservations.find(r => r.id === reservationId);
      if (reservation) {
        await apiRequest("PATCH", `/api/rooms/${reservation.roomId}`, { status: "occupied" });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Guest checked in successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to check in guest",
        variant: "destructive",
      });
    },
  });

  const checkOutMutation = useMutation({
    mutationFn: async (reservationId: string) => {
      // Update reservation status and room status
      await apiRequest("PATCH", `/api/reservations/${reservationId}`, { status: "checked_out" });
      const reservation = reservations.find(r => r.id === reservationId);
      if (reservation) {
        await apiRequest("PATCH", `/api/rooms/${reservation.roomId}`, { status: "available" });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Guest checked out successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to check out guest",
        variant: "destructive",
      });
    },
  });

  const getGuestName = (guestId: string) => {
    const guest = guests.find(g => g.id === guestId);
    return guest ? `${guest.firstName} ${guest.lastName}` : "Unknown Guest";
  };

  const getRoomNumber = (roomId: string) => {
    const room = rooms.find(r => r.id === roomId);
    return room ? room.number : "Unknown Room";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-blue-500 text-white";
      case "checked_in":
        return "bg-success text-white";
      case "checked_out":
        return "bg-neutral-500 text-white";
      case "cancelled":
        return "bg-error text-white";
      default:
        return "bg-neutral-400 text-white";
    }
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todayCheckIns = reservations.filter(r => {
    const checkIn = new Date(r.checkInDate);
    checkIn.setHours(0, 0, 0, 0);
    return checkIn.getTime() === today.getTime() && r.status === "confirmed";
  });

  const todayCheckOuts = reservations.filter(r => {
    const checkOut = new Date(r.checkOutDate);
    checkOut.setHours(0, 0, 0, 0);
    return checkOut.getTime() === today.getTime() && r.status === "checked_in";
  });

  const currentlyCheckedIn = reservations.filter(r => r.status === "checked_in");

  const filterReservations = (reservations: Reservation[]) => {
    if (!searchTerm) return reservations;
    
    return reservations.filter((reservation) => {
      const guestName = getGuestName(reservation.guestId).toLowerCase();
      const roomNumber = getRoomNumber(reservation.roomId).toLowerCase();
      return guestName.includes(searchTerm.toLowerCase()) ||
             roomNumber.includes(searchTerm.toLowerCase());
    });
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-neutral-200 rounded w-1/4"></div>
          <div className="h-64 bg-neutral-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-neutral-900">تسجيل الوصول / المغادرة</h1>
            <p className="text-neutral-600 mt-1">إدارة وصول ومغادرة النزلاء</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <Input
              placeholder="البحث عن النزلاء أو الغرف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">تسجيل وصول اليوم</p>
                <p className="text-3xl font-bold text-primary mt-2">{todayCheckIns.length}</p>
              </div>
              <LogIn className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Today's Check-outs</p>
                <p className="text-3xl font-bold text-warning mt-2">{todayCheckOuts.length}</p>
              </div>
              <LogOut className="w-8 h-8 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-medium">Currently Checked In</p>
                <p className="text-3xl font-bold text-success mt-2">{currentlyCheckedIn.length}</p>
              </div>
              <Clock className="w-8 h-8 text-success" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="checkins" className="space-y-6">
        <TabsList>
          <TabsTrigger value="checkins">Today's Check-ins</TabsTrigger>
          <TabsTrigger value="checkouts">Today's Check-outs</TabsTrigger>
          <TabsTrigger value="current">Currently Checked In</TabsTrigger>
        </TabsList>

        <TabsContent value="checkins">
          <Card>
            <CardHeader>
              <CardTitle>Today's Check-ins ({filterReservations(todayCheckIns).length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-in Time</TableHead>
                    <TableHead>Check-out Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filterReservations(todayCheckIns).map((reservation) => (
                    <TableRow key={reservation.id}>
                      <TableCell className="font-medium">
                        {getGuestName(reservation.guestId)}
                      </TableCell>
                      <TableCell>Room {getRoomNumber(reservation.roomId)}</TableCell>
                      <TableCell>
                        {new Date(reservation.checkInDate).toLocaleTimeString([], { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </TableCell>
                      <TableCell>
                        {new Date(reservation.checkOutDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(reservation.status)}>
                          {reservation.status.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => checkInMutation.mutate(reservation.id)}
                          disabled={checkInMutation.isPending}
                          className="bg-success hover:bg-success/90 text-white"
                        >
                          <LogIn className="w-4 h-4 mr-2" />
                          Check In
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filterReservations(todayCheckIns).length === 0 && (
                <div className="text-center py-8 text-neutral-500">
                  No check-ins scheduled for today
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checkouts">
          <Card>
            <CardHeader>
              <CardTitle>Today's Check-outs ({filterReservations(todayCheckOuts).length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-out Time</TableHead>
                    <TableHead>Total Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filterReservations(todayCheckOuts).map((reservation) => (
                    <TableRow key={reservation.id}>
                      <TableCell className="font-medium">
                        {getGuestName(reservation.guestId)}
                      </TableCell>
                      <TableCell>Room {getRoomNumber(reservation.roomId)}</TableCell>
                      <TableCell>
                        {new Date(reservation.checkOutDate).toLocaleTimeString([], { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </TableCell>
                      <TableCell>${reservation.totalAmount}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(reservation.status)}>
                          {reservation.status.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => checkOutMutation.mutate(reservation.id)}
                          disabled={checkOutMutation.isPending}
                          className="bg-warning hover:bg-warning/90 text-white"
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Check Out
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filterReservations(todayCheckOuts).length === 0 && (
                <div className="text-center py-8 text-neutral-500">
                  No check-outs scheduled for today
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="current">
          <Card>
            <CardHeader>
              <CardTitle>Currently Checked In ({filterReservations(currentlyCheckedIn).length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Checked In</TableHead>
                    <TableHead>Check-out Date</TableHead>
                    <TableHead>Total Amount</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filterReservations(currentlyCheckedIn).map((reservation) => (
                    <TableRow key={reservation.id}>
                      <TableCell className="font-medium">
                        {getGuestName(reservation.guestId)}
                      </TableCell>
                      <TableCell>Room {getRoomNumber(reservation.roomId)}</TableCell>
                      <TableCell>
                        {new Date(reservation.checkInDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        {new Date(reservation.checkOutDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>${reservation.totalAmount}</TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => checkOutMutation.mutate(reservation.id)}
                          disabled={checkOutMutation.isPending}
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Check Out
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filterReservations(currentlyCheckedIn).length === 0 && (
                <div className="text-center py-8 text-neutral-500">
                  No guests currently checked in
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

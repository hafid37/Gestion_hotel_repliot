import { db } from './db.js';
import { rooms } from '@shared/schema';
import { randomUUID } from 'crypto';

async function seedDatabase() {
  console.log('Seeding database with sample data...');
  
  const sampleRooms = [
    { id: randomUUID(), number: '101', floor: 1, type: 'single', status: 'available', pricePerNight: '150.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '102', floor: 1, type: 'double', status: 'occupied', pricePerNight: '200.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '103', floor: 1, type: 'double', status: 'available', pricePerNight: '200.00', capacity: 2, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '104', floor: 1, type: 'double', status: 'occupied', pricePerNight: '200.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '105', floor: 1, type: 'single', status: 'maintenance', pricePerNight: '150.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '106', floor: 1, type: 'double', status: 'occupied', pricePerNight: '200.00', capacity: 2, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '107', floor: 1, type: 'single', status: 'available', pricePerNight: '150.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '108', floor: 1, type: 'single', status: 'available', pricePerNight: '150.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '201', floor: 2, type: 'double', status: 'occupied', pricePerNight: '220.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '202', floor: 2, type: 'single', status: 'available', pricePerNight: '170.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '203', floor: 2, type: 'double', status: 'occupied', pricePerNight: '220.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '204', floor: 2, type: 'single', status: 'available', pricePerNight: '170.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '205', floor: 2, type: 'double', status: 'occupied', pricePerNight: '220.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '206', floor: 2, type: 'double', status: 'occupied', pricePerNight: '220.00', capacity: 2, amenities: ['WiFi', 'TV', 'Mini Bar'] },
    { id: randomUUID(), number: '207', floor: 2, type: 'single', status: 'available', pricePerNight: '170.00', capacity: 1, amenities: ['WiFi', 'TV'] },
    { id: randomUUID(), number: '208', floor: 2, type: 'suite', status: 'maintenance', pricePerNight: '350.00', capacity: 4, amenities: ['WiFi', 'TV', 'Mini Bar', 'Balcony'] },
  ];

  try {
    await db.insert(rooms).values(sampleRooms);
    console.log('Sample rooms inserted successfully!');
  } catch (error) {
    console.log('Sample data may already exist, skipping seed.');
  }

  process.exit(0);
}

seedDatabase();
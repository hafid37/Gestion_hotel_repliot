import { type Room, type Guest, type Reservation, type Invoice, type InsertRoom, type InsertGuest, type InsertReservation, type InsertInvoice, rooms, guests, reservations, invoices } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Room operations
  getRooms(): Promise<Room[]>;
  getRoom(id: string): Promise<Room | undefined>;
  getRoomByNumber(number: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, updates: Partial<InsertRoom>): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<boolean>;

  // Guest operations
  getGuests(): Promise<Guest[]>;
  getGuest(id: string): Promise<Guest | undefined>;
  getGuestByEmail(email: string): Promise<Guest | undefined>;
  createGuest(guest: InsertGuest): Promise<Guest>;
  updateGuest(id: string, updates: Partial<InsertGuest>): Promise<Guest | undefined>;

  // Reservation operations
  getReservations(): Promise<Reservation[]>;
  getReservation(id: string): Promise<Reservation | undefined>;
  getReservationsByGuest(guestId: string): Promise<Reservation[]>;
  getReservationsByRoom(roomId: string): Promise<Reservation[]>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
  updateReservation(id: string, updates: Partial<InsertReservation>): Promise<Reservation | undefined>;

  // Invoice operations
  getInvoices(): Promise<Invoice[]>;
  getInvoice(id: string): Promise<Invoice | undefined>;
  getInvoiceByReservation(reservationId: string): Promise<Invoice | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined>;
}

export class MemStorage implements IStorage {
  private rooms: Map<string, Room>;
  private guests: Map<string, Guest>;
  private reservations: Map<string, Reservation>;
  private invoices: Map<string, Invoice>;

  constructor() {
    this.rooms = new Map();
    this.guests = new Map();
    this.reservations = new Map();
    this.invoices = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample rooms
    const sampleRooms: Room[] = [
      { id: randomUUID(), number: "101", floor: 1, type: "single", status: "available", pricePerNight: "150.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "102", floor: 1, type: "double", status: "occupied", pricePerNight: "200.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "103", floor: 1, type: "double", status: "available", pricePerNight: "200.00", capacity: 2, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "104", floor: 1, type: "double", status: "occupied", pricePerNight: "200.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "105", floor: 1, type: "single", status: "maintenance", pricePerNight: "150.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "106", floor: 1, type: "double", status: "occupied", pricePerNight: "200.00", capacity: 2, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "107", floor: 1, type: "single", status: "available", pricePerNight: "150.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "108", floor: 1, type: "single", status: "available", pricePerNight: "150.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "201", floor: 2, type: "double", status: "occupied", pricePerNight: "220.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "202", floor: 2, type: "single", status: "available", pricePerNight: "170.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "203", floor: 2, type: "double", status: "occupied", pricePerNight: "220.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "204", floor: 2, type: "single", status: "available", pricePerNight: "170.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "205", floor: 2, type: "double", status: "occupied", pricePerNight: "220.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "206", floor: 2, type: "double", status: "occupied", pricePerNight: "220.00", capacity: 2, amenities: ["WiFi", "TV", "Mini Bar"] },
      { id: randomUUID(), number: "207", floor: 2, type: "single", status: "available", pricePerNight: "170.00", capacity: 1, amenities: ["WiFi", "TV"] },
      { id: randomUUID(), number: "208", floor: 2, type: "suite", status: "maintenance", pricePerNight: "350.00", capacity: 4, amenities: ["WiFi", "TV", "Mini Bar", "Balcony"] },
    ];

    sampleRooms.forEach(room => this.rooms.set(room.id, room));
  }

  // Room operations
  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async getRoomByNumber(number: string): Promise<Room | undefined> {
    return Array.from(this.rooms.values()).find(room => room.number === number);
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const room: Room = { 
      ...insertRoom, 
      id,
      status: insertRoom.status || "available",
      capacity: insertRoom.capacity || 1,
      amenities: insertRoom.amenities || []
    };
    this.rooms.set(id, room);
    return room;
  }

  async updateRoom(id: string, updates: Partial<InsertRoom>): Promise<Room | undefined> {
    const room = this.rooms.get(id);
    if (!room) return undefined;
    
    const updatedRoom = { ...room, ...updates };
    this.rooms.set(id, updatedRoom);
    return updatedRoom;
  }

  async deleteRoom(id: string): Promise<boolean> {
    return this.rooms.delete(id);
  }

  // Guest operations
  async getGuests(): Promise<Guest[]> {
    return Array.from(this.guests.values());
  }

  async getGuest(id: string): Promise<Guest | undefined> {
    return this.guests.get(id);
  }

  async getGuestByEmail(email: string): Promise<Guest | undefined> {
    return Array.from(this.guests.values()).find(guest => guest.email === email);
  }

  async createGuest(insertGuest: InsertGuest): Promise<Guest> {
    const id = randomUUID();
    const guest: Guest = { 
      ...insertGuest, 
      id, 
      createdAt: new Date(),
      address: insertGuest.address || null,
      idNumber: insertGuest.idNumber || null
    };
    this.guests.set(id, guest);
    return guest;
  }

  async updateGuest(id: string, updates: Partial<InsertGuest>): Promise<Guest | undefined> {
    const guest = this.guests.get(id);
    if (!guest) return undefined;
    
    const updatedGuest = { ...guest, ...updates };
    this.guests.set(id, updatedGuest);
    return updatedGuest;
  }

  // Reservation operations
  async getReservations(): Promise<Reservation[]> {
    return Array.from(this.reservations.values());
  }

  async getReservation(id: string): Promise<Reservation | undefined> {
    return this.reservations.get(id);
  }

  async getReservationsByGuest(guestId: string): Promise<Reservation[]> {
    return Array.from(this.reservations.values()).filter(reservation => reservation.guestId === guestId);
  }

  async getReservationsByRoom(roomId: string): Promise<Reservation[]> {
    return Array.from(this.reservations.values()).filter(reservation => reservation.roomId === roomId);
  }

  async createReservation(insertReservation: InsertReservation): Promise<Reservation> {
    const id = randomUUID();
    const reservation: Reservation = { 
      ...insertReservation, 
      id, 
      createdAt: new Date(),
      status: insertReservation.status || "confirmed",
      specialRequests: insertReservation.specialRequests || null
    };
    this.reservations.set(id, reservation);
    return reservation;
  }

  async updateReservation(id: string, updates: Partial<InsertReservation>): Promise<Reservation | undefined> {
    const reservation = this.reservations.get(id);
    if (!reservation) return undefined;
    
    const updatedReservation = { ...reservation, ...updates };
    this.reservations.set(id, updatedReservation);
    return updatedReservation;
  }

  // Invoice operations
  async getInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values());
  }

  async getInvoice(id: string): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async getInvoiceByReservation(reservationId: string): Promise<Invoice | undefined> {
    return Array.from(this.invoices.values()).find(invoice => invoice.reservationId === reservationId);
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const id = randomUUID();
    const invoice: Invoice = { 
      ...insertInvoice, 
      id, 
      createdAt: new Date(), 
      paidAt: null,
      status: insertInvoice.status || "pending"
    };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice) return undefined;
    
    const updatedInvoice = { ...invoice, ...updates };
    this.invoices.set(id, updatedInvoice);
    return updatedInvoice;
  }
}

export class DatabaseStorage implements IStorage {
  // Room operations
  async getRooms(): Promise<Room[]> {
    return await db.select().from(rooms);
  }

  async getRoom(id: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async getRoomByNumber(number: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.number, number));
    return room || undefined;
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const [newRoom] = await db.insert(rooms).values({
      ...room,
      id: randomUUID(),
    }).returning();
    return newRoom;
  }

  async updateRoom(id: string, updates: Partial<InsertRoom>): Promise<Room | undefined> {
    const [updatedRoom] = await db.update(rooms)
      .set(updates)
      .where(eq(rooms.id, id))
      .returning();
    return updatedRoom || undefined;
  }

  async deleteRoom(id: string): Promise<boolean> {
    const result = await db.delete(rooms).where(eq(rooms.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Guest operations
  async getGuests(): Promise<Guest[]> {
    return await db.select().from(guests);
  }

  async getGuest(id: string): Promise<Guest | undefined> {
    const [guest] = await db.select().from(guests).where(eq(guests.id, id));
    return guest || undefined;
  }

  async getGuestByEmail(email: string): Promise<Guest | undefined> {
    const [guest] = await db.select().from(guests).where(eq(guests.email, email));
    return guest || undefined;
  }

  async createGuest(guest: InsertGuest): Promise<Guest> {
    const [newGuest] = await db.insert(guests).values({
      ...guest,
      id: randomUUID(),
      createdAt: new Date(),
    }).returning();
    return newGuest;
  }

  async updateGuest(id: string, updates: Partial<InsertGuest>): Promise<Guest | undefined> {
    const [updatedGuest] = await db.update(guests)
      .set(updates)
      .where(eq(guests.id, id))
      .returning();
    return updatedGuest || undefined;
  }

  // Reservation operations
  async getReservations(): Promise<Reservation[]> {
    return await db.select().from(reservations);
  }

  async getReservation(id: string): Promise<Reservation | undefined> {
    const [reservation] = await db.select().from(reservations).where(eq(reservations.id, id));
    return reservation || undefined;
  }

  async getReservationsByGuest(guestId: string): Promise<Reservation[]> {
    return await db.select().from(reservations).where(eq(reservations.guestId, guestId));
  }

  async getReservationsByRoom(roomId: string): Promise<Reservation[]> {
    return await db.select().from(reservations).where(eq(reservations.roomId, roomId));
  }

  async createReservation(reservation: InsertReservation): Promise<Reservation> {
    const [newReservation] = await db.insert(reservations).values({
      ...reservation,
      id: randomUUID(),
      createdAt: new Date(),
    }).returning();
    return newReservation;
  }

  async updateReservation(id: string, updates: Partial<InsertReservation>): Promise<Reservation | undefined> {
    const [updatedReservation] = await db.update(reservations)
      .set(updates)
      .where(eq(reservations.id, id))
      .returning();
    return updatedReservation || undefined;
  }

  // Invoice operations
  async getInvoices(): Promise<Invoice[]> {
    return await db.select().from(invoices);
  }

  async getInvoice(id: string): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice || undefined;
  }

  async getInvoiceByReservation(reservationId: string): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.reservationId, reservationId));
    return invoice || undefined;
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const [newInvoice] = await db.insert(invoices).values({
      ...invoice,
      id: randomUUID(),
      createdAt: new Date(),
      paidAt: null,
    }).returning();
    return newInvoice;
  }

  async updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const [updatedInvoice] = await db.update(invoices)
      .set(updates)
      .where(eq(invoices.id, id))
      .returning();
    return updatedInvoice || undefined;
  }
}

export const storage = new DatabaseStorage();

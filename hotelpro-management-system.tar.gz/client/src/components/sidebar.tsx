import { Link, useLocation } from "wouter";
import { Hotel, LayoutDashboard, Bed, CalendarCheck, Users, LogIn, FileText } from "lucide-react";

const navigation = [
  { name: "لوحة التحكم", href: "/", icon: LayoutDashboard },
  { name: "إدارة الغرف", href: "/rooms", icon: Bed },
  { name: "الحجوزات", href: "/reservations", icon: CalendarCheck },
  { name: "إدارة النزلاء", href: "/guests", icon: Users },
  { name: "تسجيل الوصول/المغادرة", href: "/checkin", icon: LogIn },
  { name: "الفواتير والمحاسبة", href: "/billing", icon: FileText },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-white shadow-lg border-r border-neutral-200 flex flex-col">
      <div className="p-6 border-b border-neutral-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Hotel className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-neutral-900">فندق برو</h1>
            <p className="text-sm text-neutral-600">نظام إدارة الفنادق</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <div
                    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors cursor-pointer ${
                      isActive
                        ? "bg-primary text-white"
                        : "text-neutral-700 hover:bg-neutral-100"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.name}</span>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-neutral-200">
        <div className="flex items-center space-x-3 px-4 py-3">
          <div className="w-8 h-8 bg-neutral-300 rounded-full flex items-center justify-center">
            <Users className="text-neutral-600 text-sm" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-neutral-900">موظف الفندق</p>
            <p className="text-xs text-neutral-600">مدير مكتب الاستقبال</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

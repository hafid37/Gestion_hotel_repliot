import { Room, Guest, Reservation } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface RoomModalProps {
  room: Room | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function RoomModal({ room, isOpen, onClose }: RoomModalProps) {
  const [newStatus, setNewStatus] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reservations = [] } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
    enabled: isOpen && !!room,
  });

  const { data: guests = [] } = useQuery<Guest[]>({
    queryKey: ["/api/guests"],
    enabled: isOpen && !!room,
  });

  const updateRoomMutation = useMutation({
    mutationFn: async (data: { status: string }) => {
      if (!room) throw new Error("No room selected");
      return apiRequest("PATCH", `/api/rooms/${room.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Room status updated successfully",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update room status",
        variant: "destructive",
      });
    },
  });

  if (!room) return null;

  const currentReservation = reservations.find(
    (r) => r.roomId === room.id && r.status === "checked_in"
  );

  const currentGuest = currentReservation
    ? guests.find((g) => g.id === currentReservation.guestId)
    : null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-success text-white";
      case "occupied":
        return "bg-error text-white";
      case "maintenance":
        return "bg-warning text-white";
      case "out_of_order":
        return "bg-neutral-400 text-white";
      default:
        return "bg-neutral-400 text-white";
    }
  };

  const handleUpdateStatus = () => {
    if (newStatus && newStatus !== room.status) {
      updateRoomMutation.mutate({ status: newStatus });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Room {room.number}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex justify-between">
            <span className="text-neutral-600">Status:</span>
            <Badge className={getStatusColor(room.status)}>
              {room.status.replace("_", " ").charAt(0).toUpperCase() + room.status.slice(1)}
            </Badge>
          </div>
          
          <div className="flex justify-between">
            <span className="text-neutral-600">Type:</span>
            <span className="text-neutral-900 capitalize">{room.type}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-neutral-600">Floor:</span>
            <span className="text-neutral-900">{room.floor}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-neutral-600">Price per Night:</span>
            <span className="text-neutral-900">${room.pricePerNight}</span>
          </div>
          
          {currentGuest && (
            <>
              <div className="flex justify-between">
                <span className="text-neutral-600">Current Guest:</span>
                <span className="text-neutral-900">{currentGuest.firstName} {currentGuest.lastName}</span>
              </div>
              
              {currentReservation && (
                <>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Check-in:</span>
                    <span className="text-neutral-900">
                      {new Date(currentReservation.checkInDate).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Check-out:</span>
                    <span className="text-neutral-900">
                      {new Date(currentReservation.checkOutDate).toLocaleDateString()}
                    </span>
                  </div>
                </>
              )}
            </>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-neutral-700">Update Status</label>
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Select new status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="available">Available</SelectItem>
                <SelectItem value="occupied">Occupied</SelectItem>
                <SelectItem value="maintenance">Maintenance</SelectItem>
                <SelectItem value="out_of_order">Out of Order</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex space-x-3 mt-6">
            <Button 
              onClick={handleUpdateStatus} 
              disabled={!newStatus || newStatus === room.status || updateRoomMutation.isPending}
              className="flex-1"
            >
              {updateRoomMutation.isPending ? "Updating..." : "Update Status"}
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

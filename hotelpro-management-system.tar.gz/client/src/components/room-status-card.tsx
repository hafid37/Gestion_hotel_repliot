import { Room } from "@shared/schema";

interface RoomStatusCardProps {
  room: Room;
  onClick: (room: Room) => void;
}

export default function RoomStatusCard({ room, onClick }: RoomStatusCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-success";
      case "occupied":
        return "bg-error";
      case "maintenance":
        return "bg-warning";
      case "out_of_order":
        return "bg-neutral-400";
      default:
        return "bg-neutral-400";
    }
  };

  return (
    <div
      className={`aspect-square ${getStatusColor(
        room.status
      )} rounded-lg flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity`}
      onClick={() => onClick(room)}
    >
      <span className="text-white text-xs font-medium">{room.number}</span>
    </div>
  );
}

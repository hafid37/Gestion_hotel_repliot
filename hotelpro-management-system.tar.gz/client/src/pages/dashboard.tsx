import { useQuery } from "@tanstack/react-query";
import { Room } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Bell, Bed, UserCheck, DoorOpen, Settings } from "lucide-react";
import RoomStatusCard from "@/components/room-status-card";
import RoomModal from "@/components/room-modal";
import { useState } from "react";

interface DashboardStats {
  totalRooms: number;
  occupiedRooms: number;
  availableRooms: number;
  maintenanceRooms: number;
  outOfOrderRooms: number;
  occupancyRate: string;
  todayCheckIns: number;
  todayCheckOuts: number;
}

export default function Dashboard() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: rooms = [], isLoading: roomsLoading } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const handleRoomClick = (room: Room) => {
    setSelectedRoom(room);
  };

  const closeModal = () => {
    setSelectedRoom(null);
  };

  // Group rooms by floor
  const roomsByFloor = rooms.reduce((acc, room) => {
    if (!acc[room.floor]) {
      acc[room.floor] = [];
    }
    acc[room.floor].push(room);
    return acc;
  }, {} as Record<number, Room[]>);

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  if (statsLoading || roomsLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-neutral-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-neutral-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <header className="bg-white border-b border-neutral-200 px-8 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-neutral-900">لوحة التحكم</h2>
            <p className="text-neutral-600 mt-1">اليوم، {today}</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button className="bg-primary text-white hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              تسجيل وصول سريع
            </Button>
            <div className="relative">
              <Button variant="ghost" size="icon" className="text-neutral-600 hover:text-neutral-900">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-error text-white text-xs rounded-full flex items-center justify-center">
                  3
                </span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="p-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-neutral-600 text-sm font-medium">إجمالي الغرف</p>
                  <p className="text-3xl font-bold text-neutral-900 mt-2">{stats?.totalRooms || 0}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Bed className="text-blue-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-neutral-600 text-sm font-medium">مشغولة</p>
                  <p className="text-3xl font-bold text-success mt-2">{stats?.occupiedRooms || 0}</p>
                  <p className="text-sm text-neutral-500 mt-1">{stats?.occupancyRate || '0.0'}% نسبة الإشغال</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <UserCheck className="text-green-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-neutral-600 text-sm font-medium">متاحة</p>
                  <p className="text-3xl font-bold text-primary mt-2">{stats?.availableRooms || 0}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <DoorOpen className="text-blue-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-neutral-600 text-sm font-medium">صيانة</p>
                  <p className="text-3xl font-bold text-warning mt-2">{stats?.maintenanceRooms || 0}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Settings className="text-orange-600 text-xl" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>النشاط الأخير</CardTitle>
                  <Button variant="ghost" className="text-primary hover:text-primary/80 text-sm font-medium">
                    عرض الجميع
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-neutral-500">
                  لا يوجد نشاط حديث لعرضه
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions & Today's Schedule */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="ghost" className="w-full justify-start">
                    <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mr-3">
                      <Plus className="text-white text-sm" />
                    </div>
                    New Reservation
                  </Button>

                  <Button variant="ghost" className="w-full justify-start">
                    <div className="w-8 h-8 bg-success rounded-lg flex items-center justify-center mr-3">
                      <Bed className="text-white text-sm" />
                    </div>
                    Update Room Status
                  </Button>

                  <Button variant="ghost" className="w-full justify-start">
                    <div className="w-8 h-8 bg-warning rounded-lg flex items-center justify-center mr-3">
                      <UserCheck className="text-white text-sm" />
                    </div>
                    Generate Invoice
                  </Button>

                  <Button variant="ghost" className="w-full justify-start">
                    <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
                      <UserCheck className="text-white text-sm" />
                    </div>
                    Guest Lookup
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Today's Schedule */}
            <Card>
              <CardHeader>
                <CardTitle>Today's Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                    <div>
                      <p className="text-green-800 font-medium">Check-ins: {stats?.todayCheckIns || 0}</p>
                      <p className="text-green-600 text-sm">Starting from 3:00 PM</p>
                    </div>
                    <UserCheck className="text-green-600" />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                    <div>
                      <p className="text-red-800 font-medium">Check-outs: {stats?.todayCheckOuts || 0}</p>
                      <p className="text-red-600 text-sm">Until 12:00 PM</p>
                    </div>
                    <DoorOpen className="text-red-600" />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <div>
                      <p className="text-orange-800 font-medium">Maintenance: {stats?.maintenanceRooms || 0}</p>
                      <p className="text-orange-600 text-sm">Rooms pending service</p>
                    </div>
                    <Settings className="text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Room Status Overview */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Room Status Overview</CardTitle>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-success rounded-full"></div>
                    <span className="text-sm text-neutral-600">Available</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-error rounded-full"></div>
                    <span className="text-sm text-neutral-600">Occupied</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-warning rounded-full"></div>
                    <span className="text-sm text-neutral-600">Maintenance</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-neutral-400 rounded-full"></div>
                    <span className="text-sm text-neutral-600">Out of Order</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {Object.keys(roomsByFloor)
                .sort((a, b) => Number(a) - Number(b))
                .map((floor) => (
                  <div key={floor} className="mb-6">
                    <h4 className="text-sm font-medium text-neutral-700 mb-3">
                      Floor {floor} (Rooms {roomsByFloor[Number(floor)][0]?.number}-{roomsByFloor[Number(floor)]?.slice(-1)[0]?.number})
                    </h4>
                    <div className="grid grid-cols-8 gap-2">
                      {roomsByFloor[Number(floor)]
                        .sort((a, b) => a.number.localeCompare(b.number))
                        .map((room) => (
                          <RoomStatusCard
                            key={room.id}
                            room={room}
                            onClick={handleRoomClick}
                          />
                        ))}
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </div>
      </div>

      <RoomModal
        room={selectedRoom}
        isOpen={!!selectedRoom}
        onClose={closeModal}
      />
    </>
  );
}
